#!/usr/bin/env bash
cd "$(dirname "$0")"
source .venv/bin/activate
set -a; [ -f .env ] && source .env; set +a
if [ "$1" = "web" ]; then python -m fbtracer --web; else python -m fbtracer "$@"; fi
