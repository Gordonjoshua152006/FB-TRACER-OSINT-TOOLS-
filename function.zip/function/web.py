from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, jsonify, render_template_string, request

from . import report
from .engine import Tracer

app = Flask(__name__)
OUT = Path("reports")

PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>fbtracer</title><style>
:root{--bg:#07090f;--card:#0e1220;--line:#1c2438;--txt:#e7ecf5;--dim:#7b88a1;--acc:#00e0b8;--warn:#ffb347}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(900px 500px at 50% -10%,#0d2a2a 0%,var(--bg) 60%);
color:var(--txt);font:15px/1.6 ui-monospace,"JetBrains Mono",Consolas,monospace;min-height:100vh;padding:48px 20px}
.wrap{max-width:820px;margin:0 auto}
h1{font-size:26px;letter-spacing:.2em;text-transform:uppercase;color:var(--acc);margin:0 0 6px}
.sub{color:var(--dim);font-size:11px;letter-spacing:.24em;text-transform:uppercase;margin-bottom:32px}
form{display:flex;gap:10px;margin-bottom:28px}
input{flex:1;background:var(--card);border:1px solid var(--line);border-radius:12px;
color:var(--txt);padding:15px 18px;font:inherit;outline:none}
input:focus{border-color:var(--acc);box-shadow:0 0 0 3px #00e0b822}
button{background:var(--acc);color:#04120f;border:0;border-radius:12px;padding:15px 26px;
font:inherit;font-weight:700;letter-spacing:.1em;text-transform:uppercase;cursor:pointer}
button:disabled{opacity:.45;cursor:wait}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:22px;margin-bottom:14px;
animation:up .35s ease both}@keyframes up{from{opacity:0;transform:translateY(10px)}}
.card h2{font-size:11px;letter-spacing:.2em;text-transform:uppercase;color:var(--acc);margin:0 0 14px}
.row{display:flex;gap:14px;padding:8px 0;border-bottom:1px dashed var(--line);font-size:14px}
.row:last-child{border:0}.k{color:var(--dim);min-width:140px;flex-shrink:0;word-break:break-word}
.v{word-break:break-all}a{color:var(--acc)}
img{width:110px;height:110px;object-fit:cover;border-radius:12px;border:1px solid var(--line)}
.bar{height:7px;background:#141b2b;border-radius:99px;overflow:hidden;margin-top:8px}
.bar i{display:block;height:100%;background:linear-gradient(90deg,var(--acc),#3d7dff)}
.tag{display:inline-block;background:#12202b;color:var(--acc);border:1px solid #1d3a44;
padding:3px 10px;border-radius:99px;font-size:12px;margin:3px 5px 3px 0}
.err{color:var(--warn)}
.credit{color:var(--dim);font-size:11px;letter-spacing:.2em;text-transform:uppercase;
margin-top:28px;border-top:1px solid var(--line);padding-top:16px}
</style></head><body><div class="wrap">
<h1>fbtracer</h1><div class="sub">public data &middot; no login required</div>
<form id="f"><input id="q" placeholder="Pangalan, username, ID, o FB link" autocomplete="off" required>
<button id="b">Trace</button></form>
<div id="out"></div><div class="credit">developed by Joshua D. Gordon</div></div>
<script>
const f=document.getElementById('f'),q=document.getElementById('q'),
b=document.getElementById('b'),out=document.getElementById('out');
const e=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function row(k,v){return v?`<div class="row"><span class="k">${e(k)}</span><span class="v">${e(v)}</span></div>`:''}
function tags(t,arr){return arr&&arr.length?`<div class="card"><h2>${e(t)}</h2>${arr.map(x=>`<span class="tag">${e(x)}</span>`).join('')}</div>`:''}
f.onsubmit=async ev=>{ev.preventDefault();b.disabled=true;out.innerHTML='<div class="card"><h2>scanning…</h2></div>';
try{const r=await fetch('/api/trace',{method:'POST',headers:{'Content-Type':'application/json'},
body:JSON.stringify({query:q.value})});const d=await r.json();
if(d.error){out.innerHTML=`<div class="card"><h2 class="err">error</h2>${e(d.error)}</div>`;return}
const p=d.profile;
out.innerHTML=`<div class="card"><h2>identity</h2>
<div style="display:flex;gap:18px">${p.picture_url?`<img src="${e(p.picture_url)}">`:''}
<div style="flex:1">${row('URL',p.url)}${row('ID',p.profile_id)}${row('Username',p.username)}
${row('Pangalan',p.display_name)}${row('Bio',p.bio)}${row('Lokasyon',p.location)}
${row('Trabaho',p.work)}${row('Eskwelahan',p.education)}${row('Birthday',p.birthday)}
${row('Followers',p.followers)}${row('Matched by',p.matched_by)}</div></div>
<div style="margin-top:16px"><span class="k">confidence</span> ${p.confidence}%
<div class="bar"><i style="width:${p.confidence}%"></i></div></div>
<a href="/report/${e(d.slug)}.html" target="_blank">buksan ang full report →</a></div>`
+tags('emails',p.emails)+tags('phones',p.phones)+tags('websites',p.websites)
+tags('candidates',p.candidates)+tags('sources',p.sources)+tags('notes',p.notes);
}catch(err){out.innerHTML=`<div class="card"><h2 class="err">error</h2>${e(err)}</div>`}
finally{b.disabled=false}};
</script></body></html>"""


@app.get("/")
def index():
    return render_template_string(PAGE)


@app.post("/api/trace")
def api_trace():
    data = request.get_json(silent=True) or {}
    target = (data.get("query") or "").strip()
    if not target:
        return jsonify(error="Walang input."), 400
    try:
        prof = Tracer(
            delay=float(os.getenv("REQUEST_DELAY", "1.5")),
            graph_token=os.getenv("FB_GRAPH_TOKEN", ""),
        ).trace(target)
    except LookupError as e:
        return jsonify(error=str(e)), 404
    except Exception as e:
        return jsonify(error=str(e)), 500

    OUT.mkdir(exist_ok=True)
    slug = (prof.username or prof.profile_id or "query").replace("/", "_")[:40]
    report.to_html(prof, OUT / f"{slug}.html")
    report.to_json(prof, OUT / f"{slug}.json")
    return jsonify(profile=prof.to_dict(), slug=slug)


@app.get("/report/<name>")
def serve_report(name: str):
    p = OUT / name
    return p.read_text(encoding="utf-8") if p.exists() else ("wala", 404)


def run() -> None:
    print("  fbtracer dashboard → http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False)
