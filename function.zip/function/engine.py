from __future__ import annotations

import hashlib
import random
import re
import time
from dataclasses import asdict, dataclass, field
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

from .search import SearchEngine, is_fb_url, normalize

TIMEOUT = 25

UA_DESKTOP = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
]
UA_MOBILE = [
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
]

NOT_FOUND = (
    "page you requested was not found",
    "content isn't available",
    "the link you followed may be broken",
    "page isn't available",
    "profile isn't available",
    "this page isn't available",
)

ID_PATTERNS = [
    r'"userID":"(\d+)"',
    r'"profile_id":(\d+)',
    r'profile\.php\?id=(\d+)',
    r'"delegate_page":\{"id":"(\d+)"',
    r'entity_id["\s:=]+(\d+)',
]

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]{2,}")
PHONE_RE = re.compile(r"(?:\+63|0)9\d{9}|\+\d{1,3}[\s\-]?\d{2,4}[\s\-]?\d{3,4}[\s\-]?\d{3,4}")


@dataclass
class Profile:
    query: str
    matched_by: str = ""
    profile_id: str = ""
    username: str = ""
    display_name: str = ""
    url: str = ""
    picture_url: str = ""
    bio: str = ""
    location: str = ""
    work: str = ""
    education: str = ""
    birthday: str = ""
    gender: str = ""
    languages: str = ""
    followers: str = ""
    emails: list[str] = field(default_factory=list)
    phones: list[str] = field(default_factory=list)
    websites: list[str] = field(default_factory=list)
    socials: dict[str, str] = field(default_factory=dict)
    candidates: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    confidence: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


class Tracer:
    def __init__(self, delay: float = 1.5, graph_token: str = "", timeout: int = TIMEOUT):
        self.delay = delay
        self.token = graph_token
        self.timeout = timeout
        self.s = requests.Session()
        self.s.headers.update({"Accept-Language": "en-US,en;q=0.9"})
        self.search = SearchEngine(self.s, timeout)

    def _get(self, url: str, mobile: bool = False, allow_redirects: bool = True):
        ua = random.choice(UA_MOBILE if mobile else UA_DESKTOP)
        last = None
        for attempt in range(3):
            try:
                r = self.s.get(
                    url,
                    headers={"User-Agent": ua},
                    timeout=self.timeout,
                    allow_redirects=allow_redirects,
                )
                time.sleep(self.delay + random.uniform(0, 0.6))
                return r
            except requests.RequestException as e:
                last = e
                time.sleep(1.5 * (attempt + 1))
        raise last

    @staticmethod
    def parse_input(raw: str) -> tuple[str, str]:
        raw = raw.strip()
        if is_fb_url(raw):
            n = normalize(raw)
            if n:
                return "url", n
            return "url", raw
        if raw.startswith("@"):
            return "username", raw[1:]
        if raw.isdigit():
            return "id", raw
        if re.fullmatch(r"[\w.]{5,}", raw) and " " not in raw:
            return "username", raw
        return "name", raw

    def resolve(self, kind: str, value: str) -> tuple[str, list[str]]:
        if kind == "url":
            return value, [value]
        if kind == "id":
            return f"https://www.facebook.com/profile.php?id={value}", [
                f"https://www.facebook.com/profile.php?id={value}"
            ]
        if kind == "username":
            return f"https://www.facebook.com/{value}", [f"https://www.facebook.com/{value}"]
        found = self.search.facebook_profiles(value, limit=8)
        if not found:
            raise LookupError("Walang nahanap na profile para sa pangalang iyon.")
        return found[0], found

    def scrape(self, url: str, prof: Profile) -> bool:
        path = urlparse(url).path
        query = urlparse(url).query
        suffix = f"{path}?{query}" if query else path

        for base, mobile in (
            ("https://mbasic.facebook.com", True),
            ("https://m.facebook.com", True),
            ("https://www.facebook.com", False),
        ):
            try:
                r = self._get(base + suffix, mobile=mobile)
            except requests.RequestException:
                continue
            text = r.text
            low = text.lower()
            prof.sources.append(f"{base}{suffix} (HTTP {r.status_code})")

            if any(m in low for m in NOT_FOUND):
                continue
            if r.status_code >= 400:
                continue

            soup = BeautifulSoup(text, "lxml")

            for pat in ID_PATTERNS:
                m = re.search(pat, text)
                if m:
                    prof.profile_id = m.group(1)
                    break

            if not prof.display_name:
                t = soup.find("title")
                if t and t.get_text(strip=True):
                    name = re.sub(r"\s*\|.*$", "", t.get_text(strip=True)).strip()
                    name = re.sub(r"^\(\d+\+?\)\s*", "", name)
                    if name and len(name) < 80 and "facebook" not in name.lower():
                        prof.display_name = name

            if not prof.bio:
                for sel in ("#bio", "div#cover div", "div[data-sigil='intro-card']"):
                    node = soup.select_one(sel)
                    if node:
                        txt = node.get_text(" ", strip=True)
                        if 3 < len(txt) < 400:
                            prof.bio = txt
                            break

            for e in EMAIL_RE.findall(text):
                e = e.lower().strip(".,;")
                if e not in prof.emails and "facebook" not in e and "sentry" not in e:
                    prof.emails.append(e)
            for p in PHONE_RE.findall(text):
                p = p.strip()
                if p not in prof.phones:
                    prof.phones.append(p)

            for a in soup.find_all("a", href=True):
                href = a["href"]
                if href.startswith("http") and "facebook.com" not in href and "l.facebook" not in href:
                    if href not in prof.websites:
                        prof.websites.append(href)
                    for key in ("github.com", "instagram.com", "twitter.com", "x.com", "linkedin.com", "youtube.com", "tiktok.com"):
                        if key in href:
                            prof.socials[key.split(".")[0]] = href

            if prof.display_name or prof.profile_id:
                return True
        return False

    def picture(self, prof: Profile) -> None:
        if not prof.profile_id:
            return
        url = (
            f"https://graph.facebook.com/{prof.profile_id}/picture"
            "?type=large&redirect=true&width=720&height=720"
        )
        try:
            r = self.s.get(url, timeout=self.timeout, allow_redirects=True)
            if r.status_code == 200 and r.headers.get("Content-Type", "").startswith("image"):
                prof.picture_url = r.url
                prof.sources.append("graph.facebook.com picture endpoint")
        except requests.RequestException:
            pass

    def graph(self, prof: Profile) -> None:
        if not self.token or not prof.profile_id:
            return
        fields = "id,name,link,email,phone,about,birthday,gender,languages,location,work,education,website,followers_count"
        try:
            r = self.s.get(
                f"https://graph.facebook.com/v19.0/{prof.profile_id}",
                params={"fields": fields, "access_token": self.token},
                timeout=self.timeout,
            )
            d = r.json()
            if "error" in d:
                prof.notes.append(f"Graph API: {d['error'].get('message', 'error')}")
                return
            prof.display_name = d.get("name", prof.display_name)
            prof.url = d.get("link", prof.url)
            if d.get("email") and d["email"] not in prof.emails:
                prof.emails.append(d["email"])
            if d.get("phone") and d["phone"] not in prof.phones:
                prof.phones.append(d["phone"])
            prof.bio = prof.bio or d.get("about", "")
            prof.gender = d.get("gender", "")
            prof.birthday = d.get("birthday", "")
            prof.languages = ", ".join(
                x.get("name", "") for x in d.get("languages", []) if isinstance(x, dict)
            )
            loc = d.get("location") or {}
            prof.location = loc.get("name", "")
            prof.followers = str(d.get("followers_count", ""))
            prof.sources.append("Graph API v19.0")
        except Exception as e:
            prof.notes.append(f"Graph API failed: {e}")

    def contact_hunt(self, prof: Profile) -> None:
        seeds = [x for x in (prof.display_name, prof.username) if x]
        for seed in seeds[:1]:
            for u in self.search.facebook_profiles(seed, limit=6):
                if u not in prof.candidates:
                    prof.candidates.append(u)
            if "@" in seed or PHONE_RE.fullmatch(seed):
                continue
            for p in self.search.facebook_profiles(seed, limit=4):
                if p not in prof.candidates:
                    prof.candidates.append(p)

    def gravatar(self, prof: Profile) -> None:
        for email in list(prof.emails)[:3]:
            h = hashlib.md5(email.lower().encode()).hexdigest()
            url = f"https://www.gravatar.com/avatar/{h}?d=404&s=400"
            try:
                if self.s.head(url, timeout=self.timeout).status_code == 200:
                    prof.socials.setdefault("gravatar", f"https://www.gravatar.com/{h}")
                    prof.sources.append("gravatar")
            except requests.RequestException:
                pass

    @staticmethod
    def score(prof: Profile) -> int:
        s = 0
        if prof.profile_id:
            s += 25
        if prof.display_name:
            s += 25
        if prof.picture_url:
            s += 15
        if prof.bio:
            s += 10
        if prof.location or prof.work or prof.education:
            s += 10
        if prof.emails or prof.phones:
            s += 10
        if prof.url:
            s += 5
        if prof.username:
            s += 5
        return min(s, 100)

    def trace(self, raw: str) -> Profile:
        kind, value = self.parse_input(raw)
        prof = Profile(query=raw, matched_by=kind)
        canonical, candidates = self.resolve(kind, value)
        prof.candidates = candidates

        ok = self.scrape(canonical, prof)
        if not ok:
            for alt in candidates[1:]:
                if self.scrape(alt, prof):
                    canonical = alt
                    break

        if kind == "username" or (kind == "url" and "/" in urlparse(canonical).path):
            path = urlparse(canonical).path.strip("/").split("/")
            if path and path[0] not in ("profile.php", "people"):
                prof.username = path[0]

        prof.url = canonical
        self.picture(prof)
        self.graph(prof)
        self.gravatar(prof)
        prof.confidence = self.score(prof)
        if prof.confidence < 40:
            prof.notes.append("Mababa ang confidence — baka private o mali ang input.")
        return prof
