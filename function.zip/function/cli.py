from __future__ import annotations

import os
import sys
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .engine import Profile, Tracer
from . import report

console = Console()
OUT = Path("reports")

BANNER = r"""
  ___ _    ___  _____ ___   _   ___ ___
 | __| |__| _ )|_   _| _ \ /_\ | _ \ __|
 | _|| '_ \ _ \  | | |   // _ \|   / _|
 |_| |_.__/___/  |_| |_|_/_/ \_\_|_\___|
"""


def show(prof: Profile) -> None:
    console.print(
        Panel.fit(BANNER, style="bold cyan", subtitle="developed by Joshua D. Gordon")
    )

    t = Table(show_header=False, box=None, padding=(0, 2))
    t.add_column(style="dim", width=18)
    t.add_column()

    def add(k, v):
        if v:
            t.add_row(k, str(v))

    add("URL", prof.url)
    add("ID", prof.profile_id)
    add("Username", prof.username)
    add("Pangalan", prof.display_name)
    add("Bio", prof.bio)
    add("Lokasyon", prof.location)
    add("Trabaho", prof.work)
    add("Eskwelahan", prof.education)
    add("Birthday", prof.birthday)
    add("Gender", prof.gender)
    add("Followers", prof.followers)
    console.print(Panel(t, title="identity", border_style="cyan"))

    if prof.picture_url:
        console.print(Panel(Text(prof.picture_url), title="profile picture", border_style="magenta"))

    for label, items in (
        ("emails", prof.emails),
        ("phones", prof.phones),
        ("websites", prof.websites),
        ("socials", [f"{k}: {v}" for k, v in prof.socials.items()]),
        ("candidates", prof.candidates),
        ("sources", prof.sources),
        ("notes", prof.notes),
    ):
        if items:
            console.print(Panel("\n".join(map(str, items)), title=label, border_style="blue"))

    color = "green" if prof.confidence >= 70 else "yellow" if prof.confidence >= 40 else "red"
    console.print(f"\nconfidence: [{color}]{prof.confidence}%[/{color}]\n")


def save(prof: Profile) -> None:
    OUT.mkdir(exist_ok=True)
    slug = (prof.username or prof.profile_id or "query").replace("/", "_")[:40]
    j = report.to_json(prof, OUT / f"{slug}.json")
    h = report.to_html(prof, OUT / f"{slug}.html")
    console.print(f"[dim]saved:[/dim] {j}\n[dim]saved:[/dim] {h}")


def demo() -> Profile:
    return Profile(
        query="juan.dela.cruz",
        matched_by="username",
        profile_id="100000000000001",
        username="juan.dela.cruz",
        display_name="Juan Dela Cruz",
        url="https://www.facebook.com/juan.dela.cruz",
        picture_url="https://graph.facebook.com/100000000000001/picture?type=large",
        bio="BSIT student · Manila",
        location="Manila, Philippines",
        work="Freelance",
        education="Polytechnic University",
        emails=["juan.delacruz@example.com"],
        phones=["+63 917 000 0000"],
        sources=["demo data"],
        confidence=88,
    )


def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        console.print("[bold]Usage:[/bold] python -m fbtracer <name | username | id | fb-link> [--json] [--save]")
        console.print("       python -m fbtracer demo")
        console.print("       python -m fbtracer about")
        console.print("\n[dim]developed by Joshua D. Gordon[/dim]")
        return 0

    target = argv[1]

    if target in ("about", "-v", "--version"):
        console.print(Panel.fit(BANNER, style="bold cyan"))
        console.print("  fbtracer 1.0.0")
        console.print("  developed by Joshua D. Gordon")
        return 0

    if target == "demo":
        show(demo())
        return 0

    token = os.getenv("FB_GRAPH_TOKEN", "")
    if "--token" in argv:
        token = argv[argv.index("--token") + 1]
    delay = float(os.getenv("REQUEST_DELAY", "1.5"))

    with console.status("[cyan]nag-i-scrape ng public data...", spinner="dots"):
        try:
            prof = Tracer(delay=delay, graph_token=token).trace(target)
        except LookupError as e:
            console.print(f"[red]{e}[/red]")
            return 1
        except Exception as e:
            console.print(f"[red]error: {e}[/red]")
            return 1

    if "--json" in argv:
        import json
        console.print_json(json.dumps(prof.to_dict()))
    else:
        show(prof)
    if "--save" in argv:
        save(prof)
    return 0
