from __future__ import annotations

import html
import json
from datetime import datetime
from pathlib import Path

from .engine import Profile

CSS = """
:root{--bg:#07090f;--card:#0e1220;--line:#1c2438;--txt:#e7ecf5;--dim:#7b88a1;--acc:#00e0b8;--warn:#ffb347}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--txt);
font:15px/1.6 ui-monospace,"JetBrains Mono",Consolas,monospace;padding:40px 20px}
.wrap{max-width:900px;margin:0 auto}
h1{font-size:22px;letter-spacing:.14em;text-transform:uppercase;color:var(--acc);margin:0 0 4px}
.sub{color:var(--dim);font-size:12px;letter-spacing:.2em;text-transform:uppercase;margin-bottom:28px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:22px;margin-bottom:16px}
.card h2{font-size:12px;letter-spacing:.18em;text-transform:uppercase;color:var(--acc);margin:0 0 14px}
.row{display:flex;gap:14px;padding:9px 0;border-bottom:1px dashed var(--line);font-size:14px}
.row:last-child{border:0}.k{color:var(--dim);min-width:150px;flex-shrink:0}
.v{word-break:break-word}a{color:var(--acc);text-decoration:none}a:hover{text-decoration:underline}
img.pf{width:130px;height:130px;object-fit:cover;border-radius:12px;border:1px solid var(--line)}
.bar{height:8px;background:#141b2b;border-radius:99px;overflow:hidden;margin-top:8px}
.bar i{display:block;height:100%;background:linear-gradient(90deg,var(--acc),#3d7dff)}
.tag{display:inline-block;background:#12202b;color:var(--acc);border:1px solid #1d3a44;
padding:3px 10px;border-radius:99px;font-size:12px;margin:3px 5px 3px 0}
.note{color:var(--warn);font-size:13px}
"""


def to_json(prof: Profile, path: Path) -> Path:
    path.write_text(
        json.dumps(
            {"generated": datetime.now().isoformat(), "profile": prof.to_dict()},
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    return path


def to_html(prof: Profile, path: Path) -> Path:
    e = html.escape
    rows = []
    pairs = [
        ("Profile URL", prof.url),
        ("User ID", prof.profile_id),
        ("Username", prof.username),
        ("Pangalan", prof.display_name),
        ("Bio", prof.bio),
        ("Lokasyon", prof.location),
        ("Trabaho", prof.work),
        ("Eskwelahan", prof.education),
        ("Birthday", prof.birthday),
        ("Gender", prof.gender),
        ("Wika", prof.languages),
        ("Followers", prof.followers),
        ("Matched by", prof.matched_by),
    ]
    for k, v in pairs:
        if not v:
            continue
        if k == "Profile URL":
            rows.append(f'<div class="row"><span class="k">{k}</span><span class="v"><a href="{e(v)}">{e(v)}</a></span></div>')
        else:
            rows.append(f'<div class="row"><span class="k">{k}</span><span class="v">{e(v)}</span></div>')

    def taglist(items, label):
        if not items:
            return ""
        body = "".join(f'<span class="tag">{e(str(i))}</span>' for i in items)
        return f'<div class="card"><h2>{label}</h2>{body}</div>'

    pic = f'<img class="pf" src="{e(prof.picture_url)}" alt="profile">' if prof.picture_url else ""

    doc = f"""<!doctype html><html><head><meta charset="utf-8">
<title>fbtracer — {e(prof.query)}</title><style>{CSS}</style></head><body><div class="wrap">
<h1>fbtracer report</h1>
<div class="sub">query: {e(prof.query)} &middot; {datetime.now():%Y-%m-%d %H:%M}</div>
<div class="card"><h2>Identity</h2><div style="display:flex;gap:18px;align-items:flex-start">
{pic}<div style="flex:1">{''.join(rows)}</div></div>
<div style="margin-top:16px"><span class="k">Confidence</span> {prof.confidence}%
<div class="bar"><i style="width:{prof.confidence}%"></i></div></div></div>
{taglist(prof.emails, "Emails")}
{taglist(prof.phones, "Phone numbers")}
{taglist(prof.websites, "Websites")}
{taglist([f"{k}: {v}" for k, v in prof.socials.items()], "Social accounts")}
{taglist(prof.candidates, "Ibang candidates")}
{taglist(prof.sources, "Sources")}
{taglist(prof.notes, "Notes")}
<div class="sub">developed by Joshua D. Gordon</div>
</div></body></html>"""
    path.write_text(doc, encoding="utf-8")
    return path
