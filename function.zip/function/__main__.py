import sys

if __name__ == "__main__":
    if "--web" in sys.argv:
        from .web import run
        run()
    else:
        from .cli import main
        sys.exit(main(sys.argv))
