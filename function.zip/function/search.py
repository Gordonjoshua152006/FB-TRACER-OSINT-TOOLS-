from __future__ import annotations

import re
from urllib.parse import parse_qs, unquote, urlparse

import requests
from bs4 import BeautifulSoup

FB_HOSTS = ("facebook.com", "fb.com", "fb.watch", "fb.me")

PROFILE_RE = re.compile(
    r"^https?://(?:www\.|m\.|mbasic\.|web\.)?facebook\.com/"
    r"(?:profile\.php\?id=\d+|[\w.\-]{3,}|people/[^/]+/\d+)/?",
    re.I,
)


def is_fb_url(url: str) -> bool:
    try:
        host = urlparse(url).netloc.lower().replace("www.", "")
        return any(host == h or host.endswith("." + h) for h in FB_HOSTS)
    except Exception:
        return False


def normalize(url: str) -> str | None:
    try:
        p = urlparse(url)
        host = "www.facebook.com"
        path = p.path.rstrip("/")
        if not path:
            return None
        if p.path.startswith("/profile.php"):
            pid = parse_qs(p.query).get("id", [""])[0]
            return f"https://{host}/profile.php?id={pid}" if pid.isdigit() else None
        if path.startswith(("/people/", "/p/", "/groups/", "/watch/", "/reel/")):
            return f"https://{host}{path}"
        return f"https://{host}{path}"
    except Exception:
        return None


class SearchEngine:
    def __init__(self, session: requests.Session, timeout: int = 20):
        self.s = session
        self.timeout = timeout

    def _ddg(self, query: str, limit: int) -> list[str]:
        out: list[str] = []
        try:
            r = self.s.post(
                "https://html.duckduckgo.com/html/",
                data={"q": query, "kl": "us-en"},
                timeout=self.timeout,
            )
            soup = BeautifulSoup(r.text, "lxml")
            for a in soup.select("a.result__a"):
                href = a.get("href", "")
                if "uddg=" in href:
                    href = unquote(parse_qs(urlparse(href).query).get("uddg", [""])[0])
                if href and is_fb_url(href):
                    out.append(href)
                if len(out) >= limit:
                    break
        except Exception:
            pass
        return out

    def _bing(self, query: str, limit: int) -> list[str]:
        out: list[str] = []
        try:
            r = self.s.get(
                "https://www.bing.com/search",
                params={"q": query, "count": 30},
                timeout=self.timeout,
            )
            soup = BeautifulSoup(r.text, "lxml")
            for a in soup.select("li.b_algo h2 a"):
                href = a.get("href", "")
                if is_fb_url(href):
                    out.append(href)
                if len(out) >= limit:
                    break
        except Exception:
            pass
        return out

    def facebook_profiles(self, query: str, limit: int = 10) -> list[str]:
        q = f'site:facebook.com "{query}"' if " " in query else f"site:facebook.com {query}"
        found: list[str] = []
        for backend in (self._ddg, self._bing):
            for u in backend(q, limit):
                n = normalize(u)
                if n and n not in found and not any(
                    k in n for k in ("/groups/", "/watch/", "/reel/", "/p/", "/events/")
                ):
                    found.append(n)
            if len(found) >= limit:
                break
        return found[:limit]
